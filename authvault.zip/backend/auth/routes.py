from flask import Blueprint, request, jsonify, render_template, session, redirect, url_for, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User
from .rsa_utils import decrypt_password, get_public_key_as_pem, generate_rsa_keys
from .totp_utils import generate_totp_secret, verify_totp, get_totp_uri, generate_qr_code
import os

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.before_app_first_request
def setup_rsa_keys():
    """Ensure RSA keys exist before the app starts"""
    private_key_path = current_app.config['RSA_PRIVATE_KEY_PATH']
    public_key_path = current_app.config['RSA_PUBLIC_KEY_PATH']
    
    if not (os.path.exists(private_key_path) and os.path.exists(public_key_path)):
        generate_rsa_keys(private_key_path, public_key_path)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    # Handle POST request
    data = request.get_json()
    
    # Decrypt password using RSA
    encrypted_password = data.get('password')
    private_key_path = current_app.config['RSA_PRIVATE_KEY_PATH']
    
    try:
        decrypted_password = decrypt_password(encrypted_password, private_key_path)
    except Exception as e:
        return jsonify({'success': False, 'message': f'Password decryption failed: {str(e)}'}), 400
    
    # Hash the decrypted password for storage
    password_hash = generate_password_hash(decrypted_password)
    
    # Generate TOTP secret
    totp_secret = generate_totp_secret()
    
    # Create new user
    new_user = User(
        username=data.get('username'),
        email=data.get('email'),
        password_hash=password_hash,
        totp_secret=totp_secret,
        is_totp_enabled=False  # Will be enabled after user confirms TOTP setup
    )
    
    try:
        db.session.add(new_user)
        db.session.commit()
        
        # Generate TOTP URI and QR code
        totp_uri = get_totp_uri(totp_secret, new_user.username)
        qr_code = generate_qr_code(totp_uri)
        
        # Store user ID in session
        session['user_id'] = new_user.id
        session['totp_setup_required'] = True
        
        return jsonify({
            'success': True,
            'message': 'Registration successful',
            'totp_secret': totp_secret,
            'qr_code': qr_code
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Registration failed: {str(e)}'}), 500

@auth_bp.route('/setup-totp', methods=['POST'])
def setup_totp():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    
    data = request.get_json()
    totp_token = data.get('totp_token')
    
    user = User.query.get(session['user_id'])
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    # Verify TOTP token
    if verify_totp(user.totp_secret, totp_token):
        user.is_totp_enabled = True
        db.session.commit()
        session.pop('totp_setup_required', None)
        return jsonify({'success': True, 'message': 'TOTP setup completed'})
    else:
        return jsonify({'success': False, 'message': 'Invalid TOTP token'}), 400

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    # Handle POST request
    data = request.get_json()
    
    # Find user by username
    user = User.query.filter_by(username=data.get('username')).first()
    if not user:
        return jsonify({'success': False, 'message': 'Invalid username or password'}), 401
    
    # Decrypt password using RSA
    encrypted_password = data.get('password')
    private_key_path = current_app.config['RSA_PRIVATE_KEY_PATH']
    
    try:
        decrypted_password = decrypt_password(encrypted_password, private_key_path)
    except Exception as e:
        return jsonify({'success': False, 'message': f'Password decryption failed: {str(e)}'}), 400
    
    # Verify password
    if not check_password_hash(user.password_hash, decrypted_password):
        return jsonify({'success': False, 'message': 'Invalid username or password'}), 401
    
    # If TOTP is enabled, require token
    if user.is_totp_enabled:
        # If TOTP token is provided, verify it
        totp_token = data.get('totp_token')
        if totp_token:
            if verify_totp(user.totp_secret, totp_token):
                # TOTP verified, complete login
                session['user_id'] = user.id
                return jsonify({'success': True, 'message': 'Login successful'})
            else:
                return jsonify({'success': False, 'message': 'Invalid TOTP token'}), 401
        else:
            # TOTP token not provided, request it
            return jsonify({
                'success': False, 
                'message': 'TOTP token required',
                'require_totp': True
            }), 401
    else:
        # TOTP not enabled, complete login
        session['user_id'] = user.id
        return jsonify({'success': True, 'message': 'Login successful'})

@auth_bp.route('/public-key', methods=['GET'])
def get_public_key():
    """Endpoint to get the RSA public key for client-side encryption"""
    public_key_path = current_app.config['RSA_PUBLIC_KEY_PATH']
    public_key = get_public_key_as_pem(public_key_path)
    return jsonify({'public_key': public_key})

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})
