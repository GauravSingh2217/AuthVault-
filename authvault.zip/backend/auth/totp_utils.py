import pyotp
import qrcode
import io
import base64

def generate_totp_secret():
    """Generate a new TOTP secret"""
    return pyotp.random_base32()

def verify_totp(secret, token):
    """Verify a TOTP token against the secret"""
    totp = pyotp.TOTP(secret)
    return totp.verify(token)

def get_totp_uri(secret, username, issuer="AuthVault"):
    """Generate a TOTP URI for QR code generation"""
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=username, issuer_name=issuer)

def generate_qr_code(totp_uri):
    """Generate a QR code image from a TOTP URI"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(totp_uri)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert PIL image to base64 string
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
    
    return f"data:image/png;base64,{img_str}"
