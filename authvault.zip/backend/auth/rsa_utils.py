from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
import base64
import os

def generate_rsa_keys(private_key_path, public_key_path):
    """Generate RSA key pair and save to files"""
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(private_key_path), exist_ok=True)
    
    # Generate key pair
    key = RSA.generate(2048)
    
    # Save private key
    with open(private_key_path, 'wb') as f:
        f.write(key.export_key('PEM'))
    
    # Save public key
    with open(public_key_path, 'wb') as f:
        f.write(key.publickey().export_key('PEM'))
    
    return True

def load_private_key(private_key_path):
    """Load RSA private key from file"""
    with open(private_key_path, 'rb') as f:
        private_key = RSA.import_key(f.read())
    return private_key

def load_public_key(public_key_path):
    """Load RSA public key from file"""
    with open(public_key_path, 'rb') as f:
        public_key = RSA.import_key(f.read())
    return public_key

def decrypt_password(encrypted_password, private_key_path):
    """Decrypt password using RSA private key"""
    # Decode base64 encrypted password
    encrypted_bytes = base64.b64decode(encrypted_password)
    
    # Load private key
    private_key = load_private_key(private_key_path)
    
    # Create cipher
    cipher = PKCS1_OAEP.new(private_key, hashAlgo=SHA256)
    
    # Decrypt
    decrypted_bytes = cipher.decrypt(encrypted_bytes)
    
    # Return decoded password
    return decrypted_bytes.decode('utf-8')

def get_public_key_as_pem(public_key_path):
    """Return public key in PEM format for client-side use"""
    with open(public_key_path, 'rb') as f:
        public_key_pem = f.read().decode('utf-8')
    return public_key_pem
