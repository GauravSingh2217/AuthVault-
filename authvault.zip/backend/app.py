from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_cors import CORS
import os
from models import db, User
from auth.routes import auth_bp
import config

app = Flask(__name__, 
            static_folder='../frontend',
            template_folder='../frontend')

# Load configuration
app.config.from_object(config.DevelopmentConfig)

# Initialize database
db.init_app(app)

# Enable CORS
CORS(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/auth')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('auth_bp.login'))
    return render_template('dashboard.html')

@app.before_first_request
def create_tables():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
