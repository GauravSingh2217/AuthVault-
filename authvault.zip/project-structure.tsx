import { Card, CardContent } from "@/components/ui/card"

export default function ProjectStructure() {
  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardContent className="p-6">
        <pre className="text-sm overflow-auto p-4 bg-gray-100 rounded-md">
          {`authvault/
├── backend/
│   ├── app.py                 # Main Flask application
│   ├── config.py              # Configuration settings
│   ├── models.py              # Database models
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── rsa_utils.py       # RSA encryption/decryption utilities
│   │   ├── totp_utils.py      # TOTP generation and verification
│   │   └── routes.py          # Authentication routes
│   ├── static/
│   │   └── keys/              # Store for RSA keys (in production use env vars)
│   └── templates/             # Flask templates (if needed)
│
├── frontend/
│   ├── index.html             # Landing page
│   ├── register.html          # Registration page
│   ├── login.html             # Login page
│   ├── dashboard.html         # User dashboard after login
│   ├── css/
│   │   └── styles.css         # CSS styles
│   └── js/
│       ├── rsa.js             # RSA encryption on client side
│       ├── auth.js            # Authentication logic
│       └── app.js             # Main application logic
│
└── README.md                  # Project documentation`}
        </pre>
      </CardContent>
    </Card>
  )
}
