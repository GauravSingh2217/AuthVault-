import ProjectStructure from "../project-structure"

export default function Page() {
  return (
    <div>
      <ProjectStructure />
    </div>
  )
}
