// Authentication functions for client-side

/**
 * Handle user registration
 */
async function register() {
  const username = document.getElementById("username").value
  const email = document.getElementById("email").value
  const password = document.getElementById("password").value
  const confirmPassword = document.getElementById("confirm-password").value

  // Validate form
  if (!username || !email || !password || !confirmPassword) {
    alert("Please fill in all fields")
    return
  }

  if (password !== confirmPassword) {
    alert("Passwords do not match")
    return
  }

  // Encrypt password
  const encryptedPassword = encryptWithRSA(password)
  if (!encryptedPassword) {
    alert("Error encrypting password. Please try again.")
    return
  }

  try {
    const response = await fetch("/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username,
        email,
        password: encryptedPassword,
      }),
    })

    const data = await response.json()

    if (data.success) {
      // Show TOTP setup
      document.getElementById("registration-form").classList.add("hidden")
      document.getElementById("totp-setup").classList.remove("hidden")

      // Set QR code and TOTP secret
      document.getElementById("qr-code").src = data.qr_code
      document.getElementById("totp-secret").textContent = data.totp_secret
    } else {
      alert(`Registration failed: ${data.message}`)
    }
  } catch (error) {
    console.error("Error during registration:", error)
    alert("An error occurred during registration. Please try again.")
  }
}

/**
 * Verify TOTP during registration
 */
async function verifyTOTP() {
  const totpToken = document.getElementById("totp-token").value

  if (!totpToken || totpToken.length !== 6) {
    alert("Please enter a valid 6-digit code")
    return
  }

  try {
    const response = await fetch("/auth/setup-totp", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        totp_token: totpToken,
      }),
    })

    const data = await response.json()

    if (data.success) {
      // Show success message
      document.getElementById("totp-setup").classList.add("hidden")
      document.getElementById("registration-success").classList.remove("hidden")
    } else {
      alert(`TOTP verification failed: ${data.message}`)
    }
  } catch (error) {
    console.error("Error during TOTP verification:", error)
    alert("An error occurred during TOTP verification. Please try again.")
  }
}

/**
 * Handle user login
 */
async function login() {
  const username = document.getElementById("username").value
  const password = document.getElementById("password").value

  // Validate form
  if (!username || !password) {
    alert("Please fill in all fields")
    return
  }

  // Encrypt password
  const encryptedPassword = encryptWithRSA(password)
  if (!encryptedPassword) {
    alert("Error encrypting password. Please try again.")
    return
  }

  try {
    const response = await fetch("/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username,
        password: encryptedPassword,
      }),
    })

    const data = await response.json()

    if (data.success) {
      // Redirect to dashboard
      window.location.href = "/dashboard"
    } else if (data.require_totp) {
      // Show TOTP verification
      document.getElementById("login-form-container").classList.add("hidden")
      document.getElementById("totp-verification").classList.remove("hidden")
    } else {
      alert(`Login failed: ${data.message}`)
    }
  } catch (error) {
    console.error("Error during login:", error)
    alert("An error occurred during login. Please try again.")
  }
}

/**
 * Verify TOTP during login
 */
async function verifyLoginTOTP() {
  const totpToken = document.getElementById("totp-token").value

  if (!totpToken || totpToken.length !== 6) {
    alert("Please enter a valid 6-digit code")
    return
  }

  try {
    const response = await fetch("/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        totp_token: totpToken,
      }),
    })

    const data = await response.json()

    if (data.success) {
      // Redirect to dashboard
      window.location.href = "/dashboard"
    } else {
      alert(`TOTP verification failed: ${data.message}`)
    }
  } catch (error) {
    console.error("Error during TOTP verification:", error)
    alert("An error occurred during TOTP verification. Please try again.")
  }
}

// Mock function for RSA encryption (replace with actual implementation)
function encryptWithRSA(password) {
  // In a real application, this would use a proper RSA encryption library
  // and the public key of the server.
  // For this example, we'll just return a simple hash.
  let hash = 0
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }
  return hash.toString()
}
