// RSA encryption utilities for client-side

import JSEncrypt from "jsencrypt"

let publicKey = null
let encrypt = null

/**
 * Initialize RSA encryption by fetching the public key from the server
 */
async function initRSA() {
  try {
    const response = await fetch("/auth/public-key")
    const data = await response.json()

    if (data.public_key) {
      publicKey = data.public_key

      // Initialize JSEncrypt
      encrypt = new JSEncrypt()
      encrypt.setPublicKey(publicKey)

      console.log("RSA encryption initialized successfully")
    } else {
      console.error("Failed to get public key")
    }
  } catch (error) {
    console.error("Error initializing RSA:", error)
  }
}

/**
 * Encrypt data using the RSA public key
 * @param {string} data - The data to encrypt
 * @returns {string|null} - The encrypted data as a base64 string, or null if encryption fails
 */
function encryptWithRSA(data) {
  if (!encrypt) {
    console.error("RSA encryption not initialized")
    return null
  }

  try {
    const encrypted = encrypt.encrypt(data)
    return encrypted
  } catch (error) {
    console.error("Error encrypting data:", error)
    return null
  }
}
