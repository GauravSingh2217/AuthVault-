// Main application logic for client-side

/**
 * Handle user logout
 */
async function logout() {
  try {
    const response = await fetch("/auth/logout", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    })

    const data = await response.json()

    if (data.success) {
      // Redirect to home page
      window.location.href = "/"
    } else {
      alert(`Logout failed: ${data.message}`)
    }
  } catch (error) {
    console.error("Error during logout:", error)
    alert("An error occurred during logout. Please try again.")
  }
}

/**
 * Check if user is authenticated
 */
async function checkAuth() {
  try {
    const response = await fetch("/auth/check", {
      method: "GET",
    })

    if (response.status === 401) {
      // Redirect to login page
      window.location.href = "/login"
    }
  } catch (error) {
    console.error("Error checking authentication:", error)
  }
}

// Check authentication on protected pages
if (window.location.pathname === "/dashboard") {
  checkAuth()
}
