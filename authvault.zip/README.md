# AuthVault: Enhanced Security Authentication System

AuthVault is a secure two-factor authentication system that implements RSA encryption and Time-based One-Time Password (TOTP) verification.

## Features

- **RSA Encryption**: Passwords are encrypted on the client side before transmission to the server.
- **Two-Factor Authentication**: Uses TOTP compatible with Google Authenticator and other authenticator apps.
- **QR Code Setup**: Easy setup of authenticator apps via QR code scanning.
- **Secure Secret Storage**: TOTP secrets and RSA keys are stored securely.

## Technology Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Python with Flask
- **Encryption**: RSA encryption implemented via PyCryptodome
- **OTP Generation**: TOTP using PyOTP
- **QR Code Generation**: qrcode Python library

## Setup and Installation

### Prerequisites

- Python 3.7+
- pip (Python package manager)
- A modern web browser

### Installation Steps

1. Clone the repository:
   \`\`\`
   git clone https://github.com/yourusername/authvault.git
   cd authvault
   \`\`\`

2. Create and activate a virtual environment:
   \`\`\`
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   \`\`\`

3. Install the required packages:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

4. Set up environment variables (optional but recommended for production):
   \`\`\`
   export SECRET_KEY="your-secret-key"
   export RSA_PRIVATE_KEY_PATH="/path/to/private_key.pem"
   export RSA_PUBLIC_KEY_PATH="/path/to/public_key.pem"
   \`\`\`

5. Run the application:
   \`\`\`
   python backend/app.py
   \`\`\`

6. Access the application in your web browser at `http://localhost:5000`

## Usage

### Registration

1. Navigate to the registration page.
2. Fill in your username, email, and password.
3. Submit the form.
4. Scan the QR code with your authenticator app (e.g., Google Authenticator).
5. Enter the 6-digit code from your authenticator app to complete registration.

### Login

1. Navigate to the login page.
2. Enter your username and password.
3. If 2FA is enabled, you'll be prompted to enter the 6-digit code from your authenticator app.
4. After successful verification, you'll be redirected to the dashboard.

## Security Considerations

- RSA keys are generated on first run and stored in the `backend/static/keys` directory. In a production environment, these should be stored securely and not in the application directory.
- TOTP secrets are stored in the database. In a production environment, these should be encrypted.
- The application uses Flask's session for authentication. In a production environment, consider using a more robust session management system.

## Development

### Project Structure

\`\`\`
authvault/
├── backend/
│   ├── app.py                 # Main Flask application
│   ├── config.py              # Configuration settings
│   ├── models.py              # Database models
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── rsa_utils.py       # RSA encryption/decryption utilities
│   │   ├── totp_utils.py      # TOTP generation and verification
│   │   └── routes.py          # Authentication routes
│   ├── static/
│   │   └── keys/              # Store for RSA keys
│   └── templates/             # Flask templates (if needed)
│
├── frontend/
│   ├── index.html             # Landing page
│   ├── register.html          # Registration page
│   ├── login.html             # Login page
│   ├── dashboard.html         # User dashboard after login
│   ├── css/
│   │   └── styles.css         # CSS styles
│   └── js/
│       ├── rsa.js             # RSA encryption on client side
│       ├── auth.js            # Authentication logic
│       └── app.js             # Main application logic
│
└── README.md                  # Project documentation
\`\`\`

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [PyCryptodome](https://pycryptodome.readthedocs.io/) for RSA encryption
- [PyOTP](https://pyotp.readthedocs.io/) for TOTP generation and verification
- [qrcode](https://github.com/lincolnloop/python-qrcode) for QR code generation
- [Flask](https://flask.palletsprojects.com/) for the web framework
- [JSEncrypt](https://github.com/travist/jsencrypt) for client-side RSA encryption
